/*Написать программу, принимающую арифметическое выражение в виде строки, и
определяющую корректность расстановки скобок в этом выражении. Учесть круглые «()»,
квадратные«[]», фигурные «{}» и угловые «<>» скобки.
Скобки считаются сбалансированными, если:
a) количество открывающихся скобок совпадает с количеством закрывающихся;
b) закрывающаяся скобка не идет раньше соответствующей ей открывающейся;
c) соблюдается принцип вложенности скобок. */

# include "Stack.h"

int main()
    {
//        queue<string> x;
//        string s = "(Hello) {World}<";
//        makeIt(s, x);
//        int size = x.size();
//        string first = x.front();
//        for (int i = 0; i < size; i++)
//            {
//                x.pop();
//                if (x.front() == first)
//                    {
//                        cout << "True" << endl;
//                    }
//                cout << x.front() << endl;
//
//            }
        string s = "((Hello)) {World}";
        cout << s << endl << (balance(s) ? "Balanced" : "Unbalanced") << endl;

        string x;
        cin >> x;
        cout << x << endl << (balance(x) ? "Balanced" : "Unbalanced") << endl;


        return 0;
    }
