#ifndef QUEUE_STACK_H
#define QUEUE_STACK_H

# include <iostream>
# include <stack>
# include <cstring>
using namespace std;

class Stack
    {

    };

//void makeIt (const string& testString, queue<string> &values);
//string find (const string& testString, int i);
//bool finder (const string& testString, int i);
//
//bool validate (const string& testString)

bool balance( string& sample);
bool openBracket(string &s, int i);
bool closeBracket(string &s, int i);
char openingBracket(string &s, int i);

#endif //QUEUE_STACK_H
