//
// Created by ray on 11.07.2020.
//

#include "Stack.h"

//string find (const string& testString, int i)
//    {
//        {
//            if (testString[i] == '(')
//                {
//                    return "(";
//                }
//            if (testString[i] == '{')
//                {
//                    return "{";
//                }
//            if (testString[i] == '[')
//                {
//                    return "[";
//                }
//            if (testString[i] == '<')
//                {
//                    return "<";
//                }
//
//            if (testString[i] == ')')
//                {
//                    return ")";
//                }
//            if (testString[i] == '}')
//                {
//                    return "}";
//                }
//            if (testString[i] == ']')
//                {
//                    return "]";
//                }
//            if (testString[i] == '>')
//                {
//                    return ">";
//                }
//        }
//    }
//
//bool finder (const string& testString, int i)
//    {
//        {
//        if (testString[i] == '(')
//            {
//                return true;
//            }
//        if (testString[i] == '{')
//            {
//                return true;
//            }
//        if (testString[i] == '[')
//            {
//                return true;
//            }
//        if (testString[i] == '<')
//            {
//                return true;
//            }
//
//        if (testString[i] == ')')
//            {
//                return true;
//            }
//        if (testString[i] == '}')
//            {
//                return true;
//            }
//        if (testString[i] == ']')
//            {
//                return true;
//            }
//        if (testString[i] == '>')
//            {
//                return true;
//            }
//        else
//            {
//                return false;
//            }
//    }
//    }
//
//void makeIt(const string& testString, queue<string> &values)
//    {
//        for (int i = 0; i < testString.size(); i++)
//            {
////                values.push(find(testString,i));
//                if (finder(testString,i))
//                    {
//                        values.push(find(testString,i));
//                    }
//            }
//    };

bool balance( string& sample)
    {
        stack<char> brackets;


        for(int i = 0 ; i < sample.length(); ++i)
            {
                if(openBracket(sample, i))
                    brackets.push(sample[i]);
                else if(closeBracket(sample, i))
                    {
                        if (brackets.empty() || brackets.top() != openingBracket(sample, i))
                            return false;
                        else
                            brackets.pop();
                    }
            }
        return brackets.empty();
    }

bool openBracket(string &s, int i)
    {
        switch(s[i])
            {
                case '(':
                case '{':
                case '[':
                case '<':
                    return true;

                default:
                    return false;
            }
    }

bool closeBracket(string &s, int i)
    {
        switch(s[i])
            {
                case ')':
                case '}':
                case ']':
                case '>':
                    return true;

                default:
                    return false;
            }
    }

char openingBracket(string &s, int i)
    {
        switch(s[i])
            {
                case ')':
                    return '(';

                case '}':
                    return '{';

                case ']':
                    return '[';

                case '>':
                    return '<';

                default:
                    return 0;
            }
    }
