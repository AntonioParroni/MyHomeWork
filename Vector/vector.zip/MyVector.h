//
// Created by ray on 03.07.2020.
//

#ifndef VECTOR_MYVECTOR_H
#define VECTOR_MYVECTOR_H

#include <iostream>
#include <vector>
using namespace std;

template <class T> class MyVector
    {
        T *array = nullptr;
        int size = 0;
        int top = 0;
        int capacity = 0;
    public:
        MyVector ();
        MyVector (int size);
        MyVector (const MyVector& c);
        MyVector (int n, int val);
        ~MyVector();
        MyVector operator=(const MyVector &vector);
        MyVector operator==(const MyVector &vector);
        MyVector operator<(MyVector &vector);
        MyVector operator>(MyVector &vector);
        MyVector operator<=(MyVector &vector);
        MyVector operator>=(MyVector &vector);
        MyVector operator!=(MyVector &vector);
        MyVector operator[](int pos);

//        friend ostream& operator<<(ostream& os, MyVector <T> &vector);

        void empty ();
        int sizE ();
        T memoryCapacity (T *last);

        void clear ();
        void insert (int pos, T val);
        void erase(int pos);
        void push_back(T value);
        void pop_back();
        void resize (int newSize);

    };



#endif //VECTOR_MYVECTOR_H
