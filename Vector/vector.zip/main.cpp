
#include "MyVector.h"



int main()
    {
    MyVector <int> x(3,3);
//    int haha = x[0];
//     int haha = static_cast<int>(x[0]);
//    cout << haha << endl;
    cout << x << endl;
    // что я только не делал чтобы он показывался..
    }
