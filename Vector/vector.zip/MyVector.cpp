//
// Created by ray on 03.07.2020.
//

#include "MyVector.h"

template<class T>
MyVector<T>::MyVector()
    {
       size = 0;
       top = 0;
       array = 0;
    };

template<class T>
MyVector<T>::MyVector(int size)
    {
        array = new T[size];
        top = size;
    }

template<class T>
MyVector<T>::MyVector(const MyVector &c)
    {
    array = c.array;
    size = c.size;
    top = c.size;
    }

template<class T>
MyVector<T>::MyVector(int n, int val)
    {
    array = new T [n];
    for (int i = 0; T value : array)
        {
            array[i] = val;
        }
        top = n;
        size = n;
    }

template<class T>
MyVector<T>::~MyVector()
    {
    delete [] array;
    size = 0;
    *array = nullptr;
    }

template<class T>
MyVector<T> MyVector<T>::operator=(const MyVector &vector)
    {
        if(&vector == this) return *this;
        delete[] array;

        array = new int[vector.size];
        for(int i = 0; i < vector.size; ++i)
            array[i] = vector[i];
        size = vector.size;
        return *this;
    }

template<class T>
MyVector<T> MyVector<T>::operator==(const MyVector &vector)
    {
        if (this->size != vector.size)
            {
                return false;
            }
            else
                {
                    bool flag;
                for (int i = 0; i < vector.size; i++)
                    {
                        if (array[i] == vector[i])
                            {
                                flag = true;
                            }
                            else {return false;}
                    }
                    if (flag)
                        {
                            return true;
                        }
                }
    }

    // очень сложно и не понятно что делать дальше если размеры не равны

template<class T>
MyVector<T> MyVector<T>::operator<(MyVector &vector)
    {
                        if (this->size < vector.size)
                        {
                        return true;
                        }

    }

template<class T>
MyVector<T> MyVector<T>::operator>(MyVector &vector)
    {
                        if (this->size > vector.size)
                        {
                        return true;
                            }
    }

template<class T>
MyVector<T> MyVector<T>::operator<=(MyVector &vector)
    {
                            if (this->size <= vector.size)
                            {
                            return true;
                            }
    }

template<class T>
MyVector<T> MyVector<T>::operator>=(MyVector &vector)
    {
                            if (this->size >= vector.size)
                            {
                            return true;
                            }
    }

template<class T>
MyVector<T> MyVector<T>::operator!=(MyVector &vector)
    {
        if (this->size != vector.size)
            {
                return true;
            }
        else
            {
                bool flag;
                for (int i = 0; i < vector.size; i++)
                    {
                        if (array[i] != vector[i])
                            {
                                flag = true;
                            }
                        else {return false;}
                    }
                if (flag)
                    {
                        return true;
                    }
            }
    }

template<class T>
MyVector<T> MyVector<T>::operator[](int pos)
    {
        return array[pos];
    }



//template<class T> //пробовал перегружать чтобы видеть результаты, безуспешно
//ostream &operator<<(ostream &os, MyVector <T> &vector)
//    {
//        os << vector;
//        return os;
//    }


template<class T>
void MyVector<T>::empty()
    {
    for (int i = 0; i < size; i++)
        {
            array [i] = 0;
        }
    }

template<class T>
int MyVector<T>::sizE()
    {
        return size;
    }

template<class T>
T MyVector<T>::memoryCapacity(T *last)
    {
        return *last - *array;
    }

template<class T>
void MyVector<T>::clear()
    {
        delete [] array;
        size = 0;
        top = 0;
        *array = nullptr;
    }

template<class T>
void MyVector<T>::insert(int pos, T val)
    {
    T *temparray = new T[size + 1];
    for (int i = 0, j = 0; i < size; i++ , j++)
    {
    bool flag;
    if (i == pos)
        {
            temparray[i] = val;
        i++;
        flag = true;
        }
        else if (flag)
    {
        temparray [j] = array[i];
    }
    else if (!flag)
{
temparray [j] = array[j];
}

}
delete [] array;
array = temparray;
++top;
++size;
    }

template<class T>
void MyVector<T>::erase(int pos)
    {
        T *temparray = new T[size - 1];
        for (int i = 0, j = 0; i < size; i++ , j++)
                    {
                        bool flag;
                        if (i == pos)
                    {
                        i++;
                        flag = true;
                    }
                    else if (flag)
                    {
                        temparray [j] = array[i];
                    }
                    else if (!flag)
                    {
                        temparray [j] = array[j];
                    }

                    }
        delete [] array;
        array = temparray;
        --top;
        --size;
    }

template<class T>
void MyVector<T>::push_back(T value)
    {
    array[top++] = value;
    }

template<class T>
void MyVector<T>::pop_back()
    {
        if (this->size == 0)
            {
                return;
            }
            else
            {
            return array[--top];
            }
    }

template<class T>
void MyVector<T>::resize(int newSize)
    {
        T *temparray = new T[newSize];
        for (int i = 0; i < newSize; i++)
            {
            temparray[i] = array[i];
            }
            delete [] array;
            array = temparray;
            size = newSize;
            top = newSize;

    }


