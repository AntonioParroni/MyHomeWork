//
// Created by ray on 24.06.2020.
//

#ifndef NEW_EMPLOYEE_H
#define NEW_EMPLOYEE_H

#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;

class Employee
    {
            private:
                char *name{};
                char *position{};
                int departament = 0;
            public:
                Employee();
                Employee(const char *n, const char *p, int d);
                Employee(const Employee &obj);
                Employee(Employee &&obj) noexcept;
                ~Employee();

                Employee &operator=(const Employee &obj);
                Employee &operator=(Employee &&obj) noexcept;

                char *getName() const;
                void setName(const char *n);
                char *getPosition() const;
                void setPosition(const char *p);
                int getDepartament() const;
                void setDepartament(int d);

                void show() const;


    };


#endif //NEW_EMPLOYEE_H
