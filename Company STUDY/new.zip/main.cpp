
# include "Company.h"
# include "Employee.h"

int main()
    {
        Company newCompany("WorstSoft", 3);
        newCompany.addEmployee("Antonio Parroni", "Cleaner", 1);
        newCompany.addEmployee("Vitali Nalivkin", "CEO", 1);
        newCompany.addEmployee("Vitali Klitschko", "Public Relations", 1);
        newCompany.addEmployee("Elon Musk", "HR", 2);
        newCompany.addEmployee("Linus Tovalds", "Engineer", 3);
        newCompany.show();
    }
