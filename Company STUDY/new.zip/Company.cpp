//
// Created by ray on 24.06.2020.
//

#include "Company.h"


Company::Company()
    {
        title = strdup("Unknown");
        size = 0;
        quantity = nullptr;
        arr = nullptr;
    }

Company::Company(const char *t, int s)
    {
        title = strdup(t);
        size = s;
        quantity = new int[size];
        for (int i = 0; i < size; ++i)
            {
                quantity[i] = 0;
            }
        arr = new Employee *[size];
    }

Company::Company(const Company &obj)
    {
        title = strdup(obj.title);
        size = obj.size;
        quantity = new int[size];
        for (int i = 0; i < size; ++i)
            quantity[i] = obj.quantity[i];
        arr = new Employee *[size];
        for (int i = 0; i < size; ++i)
            {
                arr[i] = new Employee[quantity[i]];
            }

        for (int i = 0; i < size; ++i)
            {
                for (int j = 0; j < quantity[i]; ++j)
                    {
                        arr[i][j] = obj.arr[i][j];
                    }
            }
    }

Company::Company(Company &&obj) noexcept
    {
        title = obj.title;
        size = obj.size;
        quantity = obj.quantity;
        arr = obj.arr;

        obj.title = nullptr;
        obj.size = 0;
        obj.quantity = nullptr;
        obj.arr = nullptr;
    }

Company::~Company()
    {
        delete[] title;
        if (size)
            {
                for (int i = 0; i < size; ++i)
                    {
                        if (quantity[i] > 0)
                            delete[] arr[i];
                    }
                delete[] quantity;
                delete[] arr;
            }
    }

char *Company::getTitle() const
    {
        return title;
    }

void Company::setTitle(const char *t)
    {
        title = strdup(t);
    }

int Company::getSize() const
    {
        return size;
    }

Company &Company::operator=(const Company &obj)
    {
        if (this == &obj)
            return *this;

        delete[] title;
        if (size)
            {
                for (int i = 0; i < size; ++i)
                    {
                        delete[] arr[i];
                    }
                delete[] quantity;
                delete[] arr;
            }

        title = strdup(obj.title);
        size = obj.size;
        quantity = new int[size];
        for (int i = 0; i < size; ++i)
            quantity[i] = obj.quantity[i];
        arr = new Employee *[size];
        for (int i = 0; i < size; ++i)
            {
                arr[i] = new Employee[quantity[i]];
            }

        for (int i = 0; i < size; ++i)
            {
                for (int j = 0; j < quantity[i]; ++j)
                    {
                        arr[i][j] = obj.arr[i][j];
                    }
            }

        return *this;
    }

Company &Company::operator=(Company &&obj) noexcept
    {
        if (this == &obj)
            return *this;

        delete[] title;
        if (size)
            {
                for (int i = 0; i < size; ++i)
                    {
                        delete[] arr[i];
                    }
                delete[] quantity;
                delete[] arr;
            }

        title = obj.title;
        size = obj.size;
        quantity = obj.quantity;
        arr = obj.arr;

        obj.title = nullptr;
        obj.size = 0;
        obj.quantity = nullptr;
        obj.arr = nullptr;

        return *this;
    }

void Company::show() const
    {
        cout << endl << "Company: " << title << endl;
        cout << "Name" << " Position" << endl;
        for (int i = 0; i < size; ++i)
            {
                cout << "Departament: " << i + 1 << endl;
                for (int j = 0; j < quantity[i]; ++j)
                    {
                        if (i + 1 == arr[i][j].getDepartament())
                            {
                                cout << j + 1 << ") ";
                                arr[i][j].show();
                            }
                    }
            }
    }

void Company::addEmployee(const char *n, const char *p, int d)
    {
        if (d <= 0 || d > size)
            {
                cout << "Department not found" << endl;
                return;
            }

        int dep = d - 1;
        if (quantity[dep] == 0)
            {
                arr[dep] = new Employee[1];
            } else
            {
                Employee *tmp = new Employee[quantity[dep] + 1];
                for (int i = 0; i < quantity[dep]; ++i)
                    {
                        tmp[i] = arr[dep][i];
                    }
                delete[] arr[dep];
                arr[dep] = tmp;
            }
        arr[dep][quantity[dep]].setName(n);
        arr[dep][quantity[dep]].setPosition(p);
        arr[dep][quantity[dep]++].setDepartament(d);

    }

void Company::delEmployee()
    {
        if (size == 0)
            return;

        Employee **tmp = new Employee *[size];
        for (int i = 0; i < size; ++i)
            {
                if (quantity[i] > 1)
                    tmp[i] = new Employee[quantity[i] - 1];
            }
        for (int i = 0; i < size; ++i)
            {
                for (int j = 0; j < quantity[i] - 1; ++j)
                    {
                        tmp[i][j] = arr[i][j];
                    }
            }
        for (int i = 0; i < size; ++i)
            {
                if (quantity[i] > 0)
                    delete[] arr[i];
            }
        delete[] arr;
        arr = tmp;
        for (int i = 0; i < size; ++i)
            quantity[i]--;
    }

void Company::delEmployee(int d, int p)
    {
        if (d <= 0 || d > size)
            {
                cout << "Department not found" << endl;
                return;
            }
        int dep = d - 1;
        if (p <= 0 || p > quantity[dep])
            {
                cout << "Employee number was not found" << endl;
                return;
            }
        int pos = p - 1;

        Employee *tmp = new Employee[--quantity[dep]];
        for (int i = 0, j = 0; i < quantity[dep]; ++i, ++j)
            {
                if (i == pos)
                    j++;
                tmp[i] = arr[dep][j];
            }
        delete[] arr[dep];
        arr[dep] = tmp;
    }

void Company::addDepartament()
    {
        if (size == 0)
            {
                arr = new Employee *[1];
                quantity = new int[1];

            } else
            {
                Employee **tmp = new Employee *[size + 1];
                for (int i = 0; i < size; ++i)
                    {
                        if (quantity[i] > 0)
                            tmp[i] = new Employee[quantity[i]];
                    }
                for (int i = 0; i < size; ++i)
                    {
                        for (int j = 0; j < quantity[i]; ++j)
                            {
                                tmp[i][j] = arr[i][j];
                            }
                    }
                for (int i = 0; i < size; ++i)
                    {
                        if (quantity[i] > 0)
                            delete[] arr[i];
                    }
                delete[] arr;
                arr = tmp;

                int *tmpq = new int[size + 1];
                for (int i = 0; i < size; ++i)
                    {
                        tmpq[i] = quantity[i];
                    }
                delete[] quantity;
                quantity = tmpq;
            }
        quantity[size++] = 0;

    }

void Company::delDepartament(int pos)
    {
        if (pos <= 0 || pos > size)
            {
                cout << "No Department" << endl;
                return;
            }
        pos--;

        Employee **tmp = new Employee *[--size];
        for (int i = 0, j = 0; i < size; ++i, j++)
            {
                if (i == pos)
                    j++;
                if (quantity[j] > 0)
                    tmp[i] = new Employee[quantity[j]];
            }
        for (int i = 0, k = 0; i < size; ++i, ++k)
            {
                if (i == pos)
                    k++;
                for (int j = 0; j < quantity[k]; ++j)
                    {
                        tmp[i][j] = arr[k][j];
                        if (k > i)
                            tmp[i][j].setDepartament((arr[k][j].getDepartament() - 1));
                    }
            }
        for (int i = 0; i < size + 1; ++i)
            {
                if (quantity[i] > 0)
                    delete[] arr[i];
            }
        delete[] arr;
        arr = tmp;

        int *tmpq = new int[size];
        for (int i = 0, j = 0; i < size; ++i, ++j)
            {
                if (i == pos)
                    j++;
                tmpq[i] = quantity[j];
            }
        delete[] quantity;
        quantity = tmpq;
    }