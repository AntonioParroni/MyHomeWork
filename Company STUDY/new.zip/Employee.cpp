#include "Employee.h"

Employee::Employee(const char *n, const char *p, int d)
    {
        name = strdup(n);
        position = strdup(p);
        departament = d;
    }

Employee::Employee() : Employee("NoName", "NoPosition", 0)
    {

    }

Employee::Employee(const Employee &obj)
    {
        name = strdup(obj.name);
        position = strdup(obj.position);
        departament = obj.departament;
    }

Employee::Employee(Employee &&obj) noexcept
    {
        name = obj.name;
        position = obj.position;
        departament = obj.departament;

        obj.name = nullptr;
        obj.position = nullptr;
        obj.departament = 0;
    }

Employee::~Employee()
    {
        delete[] name;
        delete[] position;
    }

Employee &Employee::operator=(const Employee &obj)
    {
        if (this == &obj)
            return *this;

        delete[] name;
        delete[] position;

        name = strdup(obj.name);
        position = strdup(obj.position);
        departament = obj.departament;

        return *this;
    }

Employee &Employee::operator=(Employee &&obj) noexcept
    {
        if (this == &obj)
            return *this;

        delete[] name;
        delete[] position;

        name = obj.name;
        position = obj.position;
        departament = obj.departament;

        obj.name = nullptr;
        obj.position = nullptr;
        obj.departament = 0;

        return *this;
    }

char *Employee::getName() const
    {
        return name;
    }

void Employee::setName(const char *n)
    {
        delete[] name;
        name = strdup(n);
    }

char *Employee::getPosition() const
    {
        return position;
    }

void Employee::setPosition(const char *p)
    {
        delete[] position;
        position = strdup(p);
    }

int Employee::getDepartament() const
    {
        return departament;
    }

void Employee::setDepartament(int d)
    {
        departament = d;
    }

void Employee::show() const
    {
        cout << " " << name << " " << position << endl;
    }