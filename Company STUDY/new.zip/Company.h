//
// Created by ray on 24.06.2020.
//

#ifndef NEW_COMPANY_H
#define NEW_COMPANY_H

#include "Employee.h"


class Company
    {
    private:
        char *title{};
        int size;
        int *quantity{};
        Employee **arr{};

    public:
        Company();
        explicit Company(const char *title, int num_of_deps);
        Company(const Company &obj);
        Company(Company &&obj) noexcept;
        ~Company();

        char *getTitle() const;
        void setTitle(const char *title);
        int getSize() const;

        Company &operator=(const Company &obj);
        Company &operator=(Company &&obj) noexcept;

        void show() const;

        void addEmployee(const char *name, const char *pos, int dep);
        void delEmployee();
        void delEmployee(int dep, int pos);
        void addDepartament();
        void delDepartament(int pos);
    };


#endif //NEW_COMPANY_H
