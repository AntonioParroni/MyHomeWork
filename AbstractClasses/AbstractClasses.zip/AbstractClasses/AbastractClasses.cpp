
#include "AbastractClasses.h"

void Police::signal()
    {
        cout << "Police is coming!" << endl;
    }

void Ambulance::signal()
    {
        cout << "Ambulance is coming!" << endl;
    }

void FireEngine::signal()
    {
        cout << "Fire Engine is coming!" << endl;
    }





void Tipper::work()
    {
        cout << "Tipper is working!" << endl;
    }

void TruckCrane::work()
    {
        cout << "Truck Crane is working!" << endl;
    }

void ConcreteMixer::work()
    {
        cout << "Concrete Mixer is working!" << endl;
    }

